package com.wosloveslife.player

/**
 * Created by zhangh on 2017/11/19.
 */
interface IPlayer {
    fun getPlayEngine(): PlayerEngine
}